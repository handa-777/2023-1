void sumstore(long x, long y, long *dest);

int main(void) {
  long x = 0L;
  sumstore(1L, 2L, &x);
  return 0;
}
