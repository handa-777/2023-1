#!/bin/bash

# Compile into *.s (assembly code files)
gcc plus.c -S -Og -fno-stack-protector -fno-asynchronous-unwind-tables
gcc sum.c -S -Og -fno-stack-protector -fno-asynchronous-unwind-tables
gcc main.c -S -Og -fno-stack-protector -fno-asynchronous-unwind-tables

# Assemble into *.o (object files)
gcc -c plus.s
gcc -c sum.s
gcc -c main.s

# Link into main (executable file)
gcc plus.o sum.o main.o -o main
