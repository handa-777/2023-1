#!/bin/bash
rm -f *.s *.o main
