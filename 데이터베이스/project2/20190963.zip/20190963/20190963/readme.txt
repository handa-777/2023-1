type 1
vehicle ID는 ve01 ~ ve10입니다. 

type 2, type 3
year는 2023을 입력해야 유의미한 결과가 출력됩니다.

type 5
customer ID는 01 ~ 10입니다. 
year, month는 2023 06을 입력해야 유의미한 결과가 출력됩니다. 