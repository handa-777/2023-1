#include <stdio.h>
#include <math.h>

void count_pages(int pages, int* arr); //0~9 개수 세는 함수
void print_nums(int* arr); //0~9의 개수를 출력하는 함수