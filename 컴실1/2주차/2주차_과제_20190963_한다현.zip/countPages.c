#include "Header.h"

void count_pages(int pages, int* arr)
{
    int count = 0;      // 자리수 변수
    int nums[10] = {0}; // 각 자리의 수를 저장하는 배열
    int n = pages;
    do
    {                         // pages의 자리수와 각 자리의 수 구하기
        nums[count] = n % 10; // 각 자리의 수를 배열에 저장
        n /= 10;
        count++; // 자리수 +1
    } while (n > 0);

    for (int i = count - 1; i >= 0; i--)
    { // nums 배열에서 뒤에서부터 i = 0까지
        int expo = i - 1;
        int sum = i * pow(10, expo); // i*(10의 i-1승)
        int total = sum * nums[i];   // sum*각 자리의 수
        for (int j = 0; j < 10; j++)
        { // 0~9의 개수를 arr 배열에 더함
            if (j == 0)
            {                    // arr[0]
                arr[j] += total; // arr[0]에 total 더함
            }
            else if (j <= nums[i])
            { // j가 nums[i]보다 작거나 같은 수일 때
                if (j == nums[i] && i != 0)
                { // j가 nums[i]와 같고 i가 0이 아닐 때
                    int po = pow(10, i);
                    arr[j] += total + (pages % po) + 1; // arr[j]에 total과 pages를 10의 i승으로 나눈 값과 1을 더한다.
                }
                else
                {                                 // j가 nums보다 작거나 i가 0일 때
                    arr[j] += total + pow(10, i); // arr[j]에 total과 10의 i승을 더한다.
                }
            }
            else
            {                    // j가 nums[i]보다 클 때
                arr[j] += total; // arr[j]에 total 더함
            }
        }
    }
}