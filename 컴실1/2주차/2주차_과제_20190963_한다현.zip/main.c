#include "Header.h"

void main() {
    int arr[10] = { 0 }; //0~9의 개수를 저장하는 배열
    int t; //test 개수
    int pages; //page 수
    scanf("%d", &t); //test 개수 입력
    for (int i = 0; i < t; i++) {
        scanf("%d", &pages); //책의 페이지 수 입력
        count_pages(pages, arr); //0~9 개수 세는 함수 호출
        print_nums(arr); //0~9 개수 출력
    }
}