#include "Header.h"

void print_nums(int* arr)
{
    for (int i = 0; i < 10; i++)
    {
        printf("%d  ", arr[i]); // 0~9 순서대로 개수 출력
        arr[i] = 0;             // arr 배열 초기화
    }
    printf("\n"); // 줄바꿈
}