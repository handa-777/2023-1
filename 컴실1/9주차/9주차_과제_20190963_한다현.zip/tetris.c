﻿#include "tetris.h"

static struct sigaction act, oact;

int main()
{
	int exit = 0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);

	srand((unsigned int)time(NULL));

	while (!exit)
	{
		clear();
		createRankList();

		switch (menu())
		{
		case MENU_PLAY:
			play();
			break;
		case MENU_RANK:
			rank();
			break;
		case MENU_EXIT:
			exit = 1;
			break;
		default:
			break;
		}
	}

	endwin();
	system("clear");
	return 0;
}

void InitTetris()
{
	int i, j;

	for (j = 0; j < HEIGHT; j++)
		for (i = 0; i < WIDTH; i++)
			field[j][i] = 0;

	nextBlock[0] = rand() % 7;
	nextBlock[1] = rand() % 7;
	nextBlock[2] = rand() % 7;
	blockRotate = 0;
	blockY = -1;
	blockX = WIDTH / 2 - 2;
	score = 0;
	gameOver = 0;
	timed_out = 0;

	DrawOutline();
	DrawField();
	DrawBlockWithFeatures(blockY, blockX, nextBlock[0], blockRotate);
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline()
{
	int i, j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0, 0, HEIGHT, WIDTH);

	/* next block을 보여주는 공간의 태두리를 그린다.*/
	move(2, WIDTH + 10);
	printw("NEXT BLOCK");
	DrawBox(3, WIDTH + 10, 4, 8);
	DrawBox(9, WIDTH + 10, 4, 8);

	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(15, WIDTH + 10);
	printw("SCORE");
	DrawBox(16, WIDTH + 10, 1, 8);
}

int GetCommand()
{
	int command;
	command = wgetch(stdscr);
	switch (command)
	{
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ': /* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	return command;
}

int ProcessCommand(int command)
{
	int ret = 1;
	int drawFlag = 0;
	switch (command)
	{
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if ((drawFlag = CheckToMove(field, nextBlock[0], (blockRotate + 1) % 4, blockY, blockX)))
			blockRotate = (blockRotate + 1) % 4;
		break;
	case KEY_DOWN:
		if ((drawFlag = CheckToMove(field, nextBlock[0], blockRotate, blockY + 1, blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if ((drawFlag = CheckToMove(field, nextBlock[0], blockRotate, blockY, blockX + 1)))
			blockX++;
		break;
	case KEY_LEFT:
		if ((drawFlag = CheckToMove(field, nextBlock[0], blockRotate, blockY, blockX - 1)))
			blockX--;
		break;
	default:
		break;
	}
	if (drawFlag)
		DrawChange(field, command, nextBlock[0], blockRotate, blockY, blockX);
	return ret;
}

void DrawField()
{
	int i, j;
	for (j = 0; j < HEIGHT; j++)
	{
		move(j + 1, 1);
		for (i = 0; i < WIDTH; i++)
		{
			if (field[j][i] == 1)
			{
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else
				printw(".");
		}
	}
}

void PrintScore(int score)
{
	move(17, WIDTH + 11);
	printw("%8d", score);
}

void DrawNextBlock(int *nextBlock)
{
	int i, j;
	for (i = 0; i < 4; i++)
	{
		move(4 + i, WIDTH + 13);
		for (j = 0; j < 4; j++)
		{
			if (block[nextBlock[1]][0][i][j] == 1)
			{
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else
				printw(" ");
		}
	}

	for (i = 0; i < 4; i++)
	{
		move(10 + i, WIDTH + 13);
		for (j = 0; j < 4; j++)
		{
			if (block[nextBlock[2]][0][i][j] == 1)
			{
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else
				printw(" ");
		}
	}
}

void DrawBlock(int y, int x, int blockID, int blockRotate, char tile)
{
	int i, j;
	for (i = 0; i < 4; i++)
		for (j = 0; j < 4; j++)
		{
			if (block[blockID][blockRotate][i][j] == 1 && i + y >= 0)
			{
				move(i + y + 1, j + x + 1);
				attron(A_REVERSE);
				printw("%c", tile);
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT, WIDTH + 10);
}

void DrawBox(int y, int x, int height, int width)
{
	int i, j;
	move(y, x);
	addch(ACS_ULCORNER);
	for (i = 0; i < width; i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for (j = 0; j < height; j++)
	{
		move(y + j + 1, x);
		addch(ACS_VLINE);
		move(y + j + 1, x + width + 1);
		addch(ACS_VLINE);
	}
	move(y + j + 1, x);
	addch(ACS_LLCORNER);
	for (i = 0; i < width; i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play()
{
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM, &act, &oact);
	InitTetris();
	do
	{
		if (timed_out == 0)
		{
			alarm(1);
			timed_out = 1;
		}

		command = GetCommand();
		if (ProcessCommand(command) == QUIT)
		{
			alarm(0);
			DrawBox(HEIGHT / 2 - 1, WIDTH / 2 - 5, 1, 10);
			move(HEIGHT / 2, WIDTH / 2 - 4);
			printw("Good-bye!!");
			refresh();
			getch();

			return;
		}
	} while (!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT / 2 - 1, WIDTH / 2 - 5, 1, 10);
	move(HEIGHT / 2, WIDTH / 2 - 4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}

char menu()
{
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

/////////////////////////첫주차 실습에서 구현해야 할 함수/////////////////////////

int CheckToMove(char field[HEIGHT][WIDTH], int currentBlock, int blockRotate, int blockY, int blockX)
{
	// user code
	// printw("1");
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			// printw("\n%d", i * j);
			if (block[currentBlock][blockRotate][i][j] == 1)
			{
				if (blockX + j > WIDTH - 1)
				{
					// printw("6");
					return 0;
				}
				else if (blockY + i >= HEIGHT - 1)
				{
					// printw("7");
					return 0;
				}
				else if (blockX + j < 0)
				{
					// printw("8");
					return 0;
				}
				else if (field[i + blockY + 1][j + blockX] == 1)
				{
					// printw("9");
					return 0;
				}
			}
		}
	}
	return 1;
}

void DrawChange(char field[HEIGHT][WIDTH], int command, int currentBlock, int blockRotate, int blockY, int blockX)
{
	// user code
	// printw("2");
	int i, j;
	// 1. 이전 블록 정보를 찾는다. ProcessCommand의 switch문을 참조할 것
	// 2. 이전 블록 정보를 지운다. DrawBlock함수 참조할 것.
	// 3. 새로운 블록 정보를 그린다.
	switch (command)
	{
	case QUIT:
		break;
	case KEY_UP:
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				if (block[currentBlock][blockRotate][i][j] == 1 && i + blockY >= 0)
				{
					move(i + blockY + 1, j + blockX + 1);
					printw("%c", '.');
				}
			}
		break;
	case KEY_DOWN:
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				if (block[currentBlock][blockRotate][i][j] == 1 && i + blockY >= 0)
				{
					move(i + blockY + 1, j + blockX + 1);
					printw("%c", '.');
				}
			}
		break;
	case KEY_RIGHT:
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				if (block[currentBlock][blockRotate][i][j] == 1 && i + blockY >= 0)
				{
					move(i + blockY + 1, j + blockX + 1);
					printw("%c", '.');
				}
			}
		break;
	case KEY_LEFT:
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				if (block[currentBlock][blockRotate][i][j] == 1 && i + blockY >= 0)
				{
					move(i + blockY + 1, j + blockX + 1);
					printw("%c", '.');
				}
			}
		break;
	default:
		break;
	}
	DrawField();
	DrawBlockWithFeatures(blockY, blockX, currentBlock, blockRotate);
	move(22, WIDTH + 11);
}

void BlockDown(int sig)
{
	// user code
	// printw("3");
	// 강의자료 p26-27의 플로우차트를 참고한다.
	// printw("%d", CheckToMove(field, nextBlock[0], blockRotate, blockY, blockX));
	if (CheckToMove(field, nextBlock[0], blockRotate, blockY, blockX) == 1)
	{
		blockY++;
		DrawChange(field, KEY_DOWN, nextBlock[0], blockRotate, blockY, blockX);
	}
	else
	{
		if (blockY == -1)
		{
			gameOver = 1;
		}
		else
		{
			score += AddBlockToField(field, nextBlock[0], blockRotate, blockY, blockX);
			score += DeleteLine(field);
			nextBlock[0] = nextBlock[1];
			nextBlock[1] = nextBlock[2];
			nextBlock[2] = rand() % 7;
			blockRotate = 0, blockY = -1, blockX = WIDTH / 2 - 2;
			DrawNextBlock(nextBlock);
			PrintScore(score);
			DrawField();
			DrawBlockWithFeatures(blockY, blockX, nextBlock[0], blockRotate);
		}
	}
	timed_out = 0;
}

int AddBlockToField(char field[HEIGHT][WIDTH], int currentBlock, int blockRotate, int blockY, int blockX)
{
	// user code
	// printw("4");
	// Block이 추가된 영역의 필드값을 바꾼다.
	int touched = 0;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (block[currentBlock][blockRotate][i][j] == 1)
			{
				if (field[blockY + i + 1][blockX + j] == 1 || blockY + i == HEIGHT - 1)
				{
					touched++;
				}
				field[blockY + i][blockX + j] = 1;
			}
		}
	}
	return touched * 10;
}

int DeleteLine(char field[HEIGHT][WIDTH])
{
	// user code
	// printw("5");
	// 1. 필드를 탐색하여, 꽉 찬 구간이 있는지 탐색한다.
	// 2. 꽉 찬 구간이 있으면 해당 구간을 지운다. 즉, 해당 구간으로 필드값을 한칸씩 내린다.
	int flag, line;
	line = 0;
	for (int i = 0; i < HEIGHT; i++)
	{
		flag = 0;
		for (int j = 0; j < WIDTH; j++)
		{
			if (field[i][j] == 0)
				break;
			flag++;
		}
		if (flag == WIDTH)
		{
			line++;
			for (int p = i; p > 0; p--)
			{
				for (int q = 0; q < WIDTH; q++)
				{
					field[p][q] = field[p - 1][q];
				}
			}
			i--;
		}
	}
	return line * line * 100;
}

///////////////////////////////////////////////////////////////////////////

void DrawShadow(int y, int x, int blockID, int blockRotate)
{
	// user code
	while (CheckToMove(field, blockID, blockRotate, y, x) == 1) // y>0
	{
		y++;
	}
	DrawBlock(y, x, blockID, blockRotate, '/');
}

void DrawBlockWithFeatures(int y, int x, int blockID, int blockRotate)
{
	DrawBlock(y, x, blockID, blockRotate, ' ');
	DrawShadow(y, x, blockID, blockRotate);
}

///////////////////////////////////////////////////////////////////////////

void createRankList()
{
	// 목적: Input파일인 "rank.txt"에서 랭킹 정보를 읽어들임, 읽어들인 정보로 랭킹 목록 생성
	// 1. "rank.txt"열기
	// 2. 파일에서 랭킹정보 읽어오기
	// 3. LinkedList로 저장
	// 4. 파일 닫기
	// printw("createRankList\n");
	FILE *fp;
	int i = 0;
	top = NULL;
	char s[NAMELEN];
	int num;

	fp = fopen("rank.txt", "r");
	if (fp == NULL)
	{
		return;
	}

	if (fscanf(fp, "%d", &score_number) != EOF)
	{
		for (i = 0; i < score_number; i++)
		{
			fscanf(fp, "%s %d", s, &num);
			list *temp = (list *)malloc(sizeof(list));
			strcpy(temp->rank_name, s);
			temp->rank_score = num;
			// printw("(%s %d)\n", temp->rank_name, temp->rank_score);

			if (top == NULL || top->rank_score < temp->rank_score)
			{
				temp->link = top;
				top = temp;
			}
			else
			{
				list *current = top;
				list *previous = NULL;
				while (current != NULL && current->rank_score > temp->rank_score)
				{
					previous = current;
					current = current->link;
				}
				if (previous != NULL)
					previous->link = temp;
				else
					top = temp;
				temp->link = current;
			}
		}
	}
	else
	{
		score_number = 0;
	}

	fclose(fp);
}

void rank()
{
	int X = 1, Y = score_number, ch, count;
	clear();
	printw("1. list ranks from X to Y\n");
	printw("2. list ranks by a specific name\n");
	printw("3. delete a specific rank\n");

	ch = wgetch(stdscr);

	if (ch == '1')
	{
		echo();
		printw("X: ");
		char chX[5];
		wgetstr(stdscr, chX);
		printw("Y: ");
		char chY[5];
		wgetstr(stdscr, chY);
		noecho();

		printw("      name      |   score   \n");
		printw("----------------------------\n");

		X = atoi(chX);
		Y = atoi(chY);

		if (X == 0)
		{
			X = 1;
		}
		if (Y == 0 || Y > score_number)
		{
			Y = score_number;
		}

		// printw("%d\n", score_number);
		// printw("%d %d\n", X, Y);

		if (X > Y)
		{
			printw("\nsearch failure: no rank in the list\n");
		}
		else
		{
			count = 1;

			list *now = top;
			while (now != NULL && count <= Y)
			{
				if (count >= X)
				{
					printw("%-16s| %d\n", now->rank_name, now->rank_score);
				}
				count++;
				now = now->link;
			}
		}
	}

	// 4-2. 메뉴2: 문자열을 받아 저장된 이름과 비교하고 이름에 해당하는 리스트를 출력
	else if (ch == '2')
	{
		char str[NAMELEN + 1];
		int check = 0;

		echo();
		printw("input the name: ");
		wgetstr(stdscr, str);
		noecho();

		printw("      name      |   score   \n");
		printw("----------------------------\n");

		list *now = top;
		while (now != NULL)
		{
			if (strcmp(now->rank_name, str) == 0)
			{
				printw("%-16s| %d\n", now->rank_name, now->rank_score);
				check++;
			}
			now = now->link;
		}
		if (check == 0)
		{
			printw("\nsearch failure: no name in the list\n");
		}
	}

	// 4-3. 메뉴3: rank번호를 입력받아 리스트에서 삭제
	else if (ch == '3')
	{
		int num;
		count = 1;

		echo();
		printw("input the rank: ");
		scanw("%d", &num);
		noecho();

		printw("      name      |   score   \n");
		printw("----------------------------\n");

		if (num > score_number || num < 1)
		{
			printw("\nsearch failure: the rank not in the list\n");
		}
		else
		{
			list *current = top;
			list *previous = NULL;
			while (current != NULL)
			{
				if (count == num)
				{
					if (previous != NULL)
					{
						previous->link = current->link;
					}
					else
					{
						top = current->link;
					}
					score_number--;
					free(current);
					break;
				}
				count++;
				previous = current;
				current = current->link;
			}
			writeRankFile();
			printw("\nresult: the rank deleted\n");
		}
	}
	getch();
}

void writeRankFile()
{
	// 목적: 추가된 랭킹 정보가 있으면 새로운 정보를 "rank.txt"에 쓰고 없으면 종료
	// int sn = 0, i;
	// 1. "rank.txt" 연다
	FILE *fp = fopen("rank.txt", "w");
	if (fp == NULL)
	{
		return;
	}

	// 2. 랭킹 정보들의 수를 "rank.txt"에 기록
	fprintf(fp, "%d\n", score_number);

	// 3. 탐색할 노드가 더 있는지 체크하고 있으면 다음 노드로 이동, 없으면 종료
	list *current = top; // Use a separate pointer to iterate through the list

	while (current != NULL)
	{
		fprintf(fp, "%s %d\n", current->rank_name, current->rank_score);
		current = current->link;
	}
	// if (sn == score_number)
	// 	return;
	// else
	// {

	// }
	// for (i = 1; i < score_number + 1; i++)
	// {
	// 	free(a.rank_name[i]);
	// }
	// free(a.rank_name);
	// free(a.rank_score);

	fclose(fp);
}

void newRank(int score)
{
	// 목적: GameOver시 호출되어 사용자 이름을 입력받고 score와 함께 리스트의 적절한 위치에 저장
	char str[NAMELEN + 1];
	// int i, j;
	clear();
	// 1. 사용자 이름을 입력받음
	echo();
	printw("your name: ");
	wgetstr(stdscr, str);
	// printw("name\n");
	noecho();
	// printw("temp\n");
	// 2. 새로운 노드를 생성해 이름과 점수를 저장, score_number가
	list *temp = (list *)malloc(sizeof(list));
	strcpy(temp->rank_name, str);
	temp->rank_score = score;
	temp->link = NULL;

	if (score_number)
	{
		// printw("hi\n");
		list *current = top;
		list *previous = NULL;
		while (current != NULL && current->rank_score > temp->rank_score)
		{
			previous = current;
			current = current->link;
		}
		if (previous != NULL)
			previous->link = temp;
		else
			top = temp;
		temp->link = current;
		score_number++;
	}
	else
	{
		// printw("else\n");
		top = temp;
		score_number = 1;
	}
	writeRankFile();
}

void DrawRecommend(int y, int x, int blockID, int blockRotate)
{
	// user code
}

// int recommend(char fieldOri[HEIGHT][WIDTH], int lv)
// {
// }

void recommendedPlay()
{
	// user code
}
