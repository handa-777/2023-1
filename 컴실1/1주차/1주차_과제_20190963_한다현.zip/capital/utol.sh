echo 'working directory' #/sogang/under/cse20131251/shell 
read dirname #directory 이름을 입력을 저장

if [ -n "$dirname" ]  
then #dirname 비어있지 않을 때
    check=`find $HOME -wholename $dirname -type d 2>/dev/null`
    if [ -z "$check" ] #디렉토리 없을 때
    then
        echo Error: no such directory.
    # elif [ cd $dirname ] #디렉토리 못 바꿀 때 추가!
    # then 
    else
        cd $dirname 2>err.log #해당 디렉토리로 이동
        error=`find $HOME -name err.log 2>/dev/null`
        if [ -s $error ]
        then 
            echo Error: cannot change directory.
        else
            cd $dirname
            for dir in *
            do
                newname=`echo $dir | tr "[a-z] [A-Z]" "[A-Z] [a-z]"` #변수 newname은 dir의  대소문자를tr을 이용해서 바꾼것
                mv $dir $newname #$dir을 newname으로 바꾼다. 
            done
        fi
    fi
else
    dirname=`pwd`
    for dir in *
    do
        newname=`echo $dir | tr "[a-z] [A-Z]" "[A-Z] [a-z]"` #변수 newname은 dir의  대소문자를tr을 이용해서 바꾼것
        mv $dir $newname #$dir을 newname으로 바꾼다. 
    done
fi

