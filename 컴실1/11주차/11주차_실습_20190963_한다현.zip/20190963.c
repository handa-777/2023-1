#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <ctype.h>

int **maze;
int height, width;
int total;

void init_maze();
void random_maze();
void print_maze();

int main()
{
    int col, row;

    scanf("%d", &col);
    scanf("%d", &row);

    width = col * 2 + 1;
    height = row * 2 + 1;
    total = width * height;

    init_maze();
    // print_maze();

    random_maze();

    print_maze();

    return 0;
}

void init_maze()
{
    int num = 1;

    maze = (int **)malloc(sizeof(int *) * height);
    for (int i = 0; i < height; i++)
    {
        maze[i] = (int *)malloc(sizeof(int) * width);
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if (i % 2 == 0)
            {
                if (j % 2 == 0)
                {
                    maze[i][j] = '+';
                }
                else
                {
                    maze[i][j] = '-';
                }
            }
            else
            {
                if (j % 2)
                {
                    if (num == 42)
                    {
                        num = 46;
                    }
                    maze[i][j] = num++;
                }
                else
                {
                    maze[i][j] = '|';
                }
            }
        }
    }
}

void random_maze()
{
    srand(time(NULL));
    int r, num;
    // int count[100] = {0};
    // int nums[100] = {0};

    // for (int q = 1; q < width - 1; q += 2)
    // {
    //     printf("%d\n", maze[1][q]);
    // }

    for (int i = 1; i < width - 2; i += 2) // first line
    {
        r = rand() % 10;
        // printf("%d\n", r);
        if (maze[1][i] != maze[1][i + 2] && r > 5)
        {
            maze[1][i + 2] = maze[1][i];
            maze[1][i + 1] = ' ';
        }
    }
    // print_maze();
    int count[500] = {0};
    int nums[500] = {0};
    for (int i = 1; i < height - 2; i += 2)
    {
        if (i != 1)
        {
            for (int k = 1; k < width - 2; k += 2)
            {
                r = rand() % 10;
                if (maze[i][k] != maze[i][k + 2] && r > 5)
                {
                    // maze[i][k + 2] = maze[i][k];
                    // maze[i][k + 1] = ' ';

                    // if (maze[i][k] > maze[i][k + 2])
                    // {
                    //     if (maze[i][k + 4] != maze[i][k + 2])
                    //     {
                    //         maze[i][k] = maze[i][k + 2];
                    //         maze[i][k + 1] = ' ';
                    //     }
                    // }
                    // else
                    // {
                    //     if (maze[i][k + 4] != maze[i][k + 2])
                    //     {
                    //         maze[i][k + 2] = maze[i][k];
                    //         maze[i][k + 1] = ' ';
                    //     }
                    // }
                    int temp = maze[i][k + 2]; // 옆으로
                    maze[i][k + 2] = maze[i][k];
                    maze[i][k + 1] = ' ';
                    for (int p = k + 4; p < width - 1; p += 2)
                    {
                        if (maze[i][p] == temp)
                        {
                            maze[i][p] = maze[i][k];
                        }
                    }
                }
            }
            for (int q = 0; q < 100; q++)
            {
                count[q] = 0;
                nums[q] = 0;
            }
        }

        for (int j = 1; j < width - 1; j += 2)
        {
            num = maze[i][j];
            r = rand() % 10;
            if (r > 5) // 아래쪽 벽 제거
            {
                maze[i + 1][j] = ' ';
                maze[i + 2][j] = maze[i][j];
                count[num - 1]++;
                nums[num - 1]++;
            }
            else
            {
                if (j + 2 >= width || maze[i][j] != maze[i][j + 2])
                {
                    if (count[num - 1] == 0)
                    {
                        maze[i + 1][j] = ' ';
                        maze[i + 2][j] = maze[i][j];
                        count[num - 1]++;
                        nums[num - 1]++;
                    }
                }
                else if (maze[i][j] == maze[i][j + 2] && maze[i][j + 1] == '|')
                {
                    maze[i + 1][j] = ' ';
                    maze[i + 2][j] = maze[i][j];
                    count[num - 1]++;
                    nums[num - 1]++;
                }
            }
        }
    }

    for (int i = 1; i < width - 2; i += 2) // last line
    {
        r = rand() % 10;
        // printf("%d\n", r);
        if (maze[height - 2][i] != maze[height - 2][i + 2])
        {
            // maze[height - 2][i + 2] = maze[height - 2][i];
            // maze[height - 2][i + 1] = ' ';
            int temp = maze[height - 2][i + 2]; // 옆으로
            maze[height - 2][i + 2] = maze[height - 2][i];
            maze[height - 2][i + 1] = ' ';
            for (int p = i + 4; p < width - 1; p += 2)
            {
                if (maze[height - 2][p] == temp)
                {
                    maze[height - 2][p] = maze[height - 2][i];
                }
            }
        }
    }
    // free(count);
    // free(nums);
}

void print_maze()
{
    FILE *fp = fopen("maze.maz", "w");

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if (maze[i][j] != '|' && maze[i][j] != '-' && maze[i][j] != '+')
            // if (isdigit(maze[i][j]))
            {
                fprintf(fp, " ");
            }
            else
                fprintf(fp, "%c", maze[i][j]);
        }
        fprintf(fp, "\n");
    }
    // for (int i = 1; i < height - 1; i += 2)
    // {
    //     for (int j = 1; j < width - 1; j += 2)
    //     {
    //         fprintf(fp, "%d ", maze[i][j]);
    //     }
    //     fprintf(fp, "\n");
    // }
    fclose(fp);
}