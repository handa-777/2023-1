#include "Str.h"
#include <cstring>
#include <iostream>
using namespace std;

Str::Str(int leng)
{
    // new를 사용하여 chr에 메모리를 할당, len값 초기화
    chr = new char[leng + 1];
    len = leng;
}
Str::Str(const char *neyong)
{
    // neyong의 길이를 len에 저장하고 new를 사용하여 chr에 neyong을 할당
    len = strlen(neyong);
    chr = new char[len + 1];
    strcpy(chr, neyong);
}
Str::~Str()
{
    // 소멸자; 할당된 메모리 해제
    delete[] chr;
}
int Str::length(void)
{
    // string의 길이 리턴
    return len;
}
char *Str::contents(void)
{
    // string의 내용 리턴
    return chr;
}
int Str::compare(class Str &a)
{
    // a의 내용과 strcmp
    return strcmp(chr, a.chr);
}
int Str::compare(const char *a)
{
    // a의 내용과 strcmp
    return strcmp(chr, a);
}

void Str::operator=(const char *a)
{
    delete[] chr;            // 기존 메모리 제거
    len = strlen(a);         // len은 a의 길이
    chr = new char[len + 1]; // chr에 메모리 할당
    strcpy(chr, a);          // string에 a의 내용 삽입
}

void Str::operator=(class Str &a)
{
    delete[] chr;            // 기존 메모리 제거
    len = strlen(a.chr);     // len은 a.chr의 길이
    chr = new char[len + 1]; // chr에 메모리 할당
    strcpy(chr, a.chr);      // string에 a.chr의 내용 삽입
}